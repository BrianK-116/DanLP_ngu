<h1><center>Pipeline HCM AI CHALLENGE <br> Event Retrieval from Visual Data</center></h1>

## Setup 
```
pip install git+https://github.com/openai/CLIP.git
pip install -r requirements.txt
```

## Run 
```
python app.py
```

URL: http://0.0.0.0:5001/home?index=0


"# AICute" 
"# AICute" 
"# AICute1" 
